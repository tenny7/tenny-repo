<?php
defined('BASEPATH') or die('Direct access is not allowed');

class MY_Controller extends CI_Controller {
  public function __construct() {
    parent::__construct();
    $this->load->helper('form');
    $this->load->library('form_validation');
    $this->load->library('session');
    $this->load->helper('url');
    $this->load->helper('captcha');
    $this->load->database();
    $this->site_name = 'Goldenaira';
	  $this->user = $this->session->number;
    //include it
    include "captcha.php";
    $_SESSION['captcha'] = simple_php_captcha();
  }
  public function is_matched() {

	$check_q = $this->db->query("SELECT * FROM users WHERE number='$this->user' AND spill_status='false'")->num_rows();
    if($check_q == 0) {
	  redirect(site_url('spillover'));
    }
  }

  public function is_restricted() {
    if ($this->session->loggedin) {
      return true;
    } else {
      redirect(site_url('login'));
    }
  }

  public function admin_restricted(){
  if ($this->session->admin_logged) {
    return true;
  } else {
    redirect(site_url('admin/index'));
  }
}
  public function checks() {

	//first of all, check if 12hrs has elapsed then BLOCK!
	//will be running queries here haha

	$query_T = $this->db->query("SELECT * FROM donations WHERE time < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 24 HOUR) AND status='pending'")->row_array();
  $q_number = $query_T['user'];
  $q_donates_to = $query_T['donates_to'];
  $q_id = $query_T['id'];
	//now check
	if ($query_T > 0) {
      //cancel the donation
      $this->db->query("UPDATE donations SET status='cancelled' WHERE id='$q_id'");
			$this->db->query("UPDATE users SET is_blocked='true' WHERE number='$q_number'");
      //give the user back his matches
      $query_M = $this->db->query("SELECT * FROM users WHERE number='$q_donates_to'")->row_array();
      $current_m = $query_M['matches'];
      $add = $current_m + 1;
      //update it
      $this->db->query("UPDATE users SET matches='$add' WHERE number='$q_donates_to'");
		}

  $queryss = $this->db->get_where('users', array('matches' => '0'));
  $resultss = $queryss->result_array();

  foreach ($resultss as $r) {
    $rnumber = $r['number'];
    //$this->db->query("UPDATE users SET eligible='false' WHERE number='$rnumber'");
  }

  //send the user packing cause his tenure is done hahahaha
  //$Cquery = $this->db->get_where('users', array('is_blocked' => 'true', 'number' => $this->session->number))->result();
  //if($Cquery) {
  //  $this->session->set_flashdata('error', 'You have been blocked, contact support.');
  //  redirect(site_url('login'));
  //}

  }

  public function header($title) {
    $data['site_name'] = $this->site_name;
    $data['title'] = $title;
    return $this->load->view('layout/header', $data);
  }

  public function footer($data = NULL) {
    $data['site_name'] = $this->site_name;
    return $this->load->view('layout/footer', $data);
  }

  public function header2($title) {
	$data['name'] = $this->dashboard_model->get_details($this->user)->name;
    $data['site_name'] = $this->site_name;
    $data['title'] = $title;
    return $this->load->view('layout/header2', $data);
  }

  public function admin_header($title) {
    $data['site_name'] = $this->site_name;
    $data['title'] = $title;
    return $this->load->view('admin/layout/header', $data);
  }

  public function admin_footer($data = NULL) {
      $data['site_name'] = $this->site_name;
      return $this->load->view('admin/layout/footer', $data);
    }

  public function footer2($data = NULL) {
    $data['site_name'] = $this->site_name;
    return $this->load->view('layout/footer2', $data);
  }
} ?>
