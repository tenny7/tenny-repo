<div class="container-fluid" style="padding:0px;">
<div class="col-md-12 homepage-slide" style="min-height: 100vh; ">
</div>
