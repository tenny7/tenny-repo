
<div class="main-container">

<div class="container">
<div class="row">
<div class="col-md-8 page-content">
<div class="inner-box category-content">
<h2 class="title-2">
<span class="fa fa-headphones"></span>
<?php echo $site_name; ?> Support Centre
</h2>
<p>
<h4>Welcome to the Support Center</h4>
Here at <?php echo $site_name; ?>, we're dedicated to making our users happy.
If you have a question or concern, you've come to the right place.


<?php include_once 'help_center.php'; ?>

</p>
<hr/>

</div>
</div>
</div>
</div>
<div class="col-md-4">
</div>

</div>

</div>

</div>
