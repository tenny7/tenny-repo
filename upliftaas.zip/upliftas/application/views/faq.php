<div class="main-container">
<div class="container">
<div class="row">
<div class="col-md-8 page-content">
<div class="inner-box category-content">
<h2 class="title-2">
<span class="fa fa-question-circle"></span> Frequently Asked Questions (FAQ<span style="text-transform: none;;">s</span>)
</h2>
<style type="text/css">.faq-container h3{font-weight:bold;font-size:16px;}.faq-container p{border-bottom:1px solid #ccc;padding:0px 10px 15px 10px;}</style>
<div class="faq-container">
<h3>What are <?php echo $site_name; ?> Terms and Conditions?</h3>
<p>
<p>  1. <?php echo $site_name; ?> is in no way reliable or accountable for any transaction done on this platform or how this platform is used, as users join out of their own free will and the whole Money circulates round the circle. </p>
<p>
  2. At <?php echo $site_name; ?> Every User have a maximum of 24hours to pay and get confirmed by his beneficiary, otherwise will be deleted automatically form the system forever without prior notice.
</p>
<p>
  3. At <?php echo $site_name; ?>, We don't play arround,and we don't allow Online Beggers. If you don't have money to donate when matched, Please do not register at all. We need serious people who are serious to make money.
</p>
<p>
  4. Every registration at <?php echo $site_name; ?> is done at freewill, and we assume you where not forced to register.This platform is only meant for people above 18years.
</p>
<p>
  5. At <?php echo $site_name; ?>, we make people smile, don't forget to tell your loved ones..
</p>

</p>
<h3>How can i join <?php echo $site_name; ?>??</h3>
<p>
  You can join <?php echo $site_name; ?> by clicking on the SIGN UP botton on the navigation bar or on the REGISTER button at the top of the homepage. Do well to provide original details while filling the form so as to avoid irregularities and/or complaints.

</p>
<h3>How can i login??</h3>
<p>
  You can login to <?php echo $site_name; ?> just by clicking on the login button on the navigation bar or on the LOG ME IN button below the picture on the homepage. Input your number and password and that's all. It is advised that you keep your password secret as that is your access pin. Anyone who has it has access to all you've got on <?php echo $site_name; ?>.

</p>
<h3>  How much do i donate or invest?</h3>
<p>
  On registering, the system immediately matches you to someone that you'll donate to. Just copy the person's phone number and account details. It is advised you call the person before payment to facilitate the confirmation process.

</p>
<h3>  How much do i get?</h3>
<p>
  As the name implies, you get 2 times the ammount you pay in. That is, with a donation of #5000, you will be paid #10000.

</p>
<h3>  do i have to bring people as my downliners before i get matched?
</h3>
<p>  Hell no! You don't have to worry yourself doing that. We found out that some people find it difficult convincing others to register as downliners and that was why the system was developed.

</p>
<h3>  How long does it take for me to get matched?</h3>
<p>

  This system is not like the rest that takes time for it to start matching newly registered people. After you get confirmed by someone you were matched to pay, the system immediately matches you to the next person that registers.

</p>
<h3>  How long does someone's account last if he or she registers but does not donate?</h3>
<p>
  At <?php echo $site_name; ?>, we took this recession into consideration and so, gave a period of 48 hours. If you dont donate after this period of time, your account gets deleted and the person you are matched to pay gets rematched.This was done so as to ensure easy recyclement and fast payment.

</p>
<h3>  How do i lay a complain to the admin??</h3>
<p>
  To lay a complain about any irregularities on your account, you can do so in two ways:
  1. navigate to the contact page and fill up the form
  2. send an email directly to admin@<?php echo $site_name;?>.com. Remember to put your username while using this method for easy rectification.
  Through which ever method you use, be rest assured that you'll get attended to almost immediately.

</p>

<h3>I made payment but my upline refused to Approve my Payment?</h3>
<p>
Please <a href="<?php echo base_url('support'); ?>">contact support</a> immediately.
</p>
</div>
</div>
</div>
<div class="col-md-4">
</div>

</div>

</div>

</div>
