<?php
  if(isset($_POST['ad_message'])){
        $msg_in=$_POST['message_area'];

        $date=date('Y-m-d H:i:s');
                
                 $data = array('id' => '', 'number' => $p['number'], 'msg_in' => $msg_in, 'msg_out' => '', 'time' => $date);
    echo "<h3 style='text-success'>Message Sent</h3>";
    return $this->db->insert('message', $data);
 
  }
?>
<?php echo form_open('admin/edit/'.$id); ?>
<?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>
<?php
$success_message = $this->session->flashdata('success_msg');
if (!empty($success_message)) { ?>
<div class="alert alert-success"><?php echo $success_message; ?> </div>
<?php } ?>
<div class="row">
<div class="col-sm-6">
<div class="box box-success">
                      <div class="box-header with-border">
                          <h3 class="box-title">
                              <strong style="color: green;">
                                  <blink><i class="fa fa-money fa-spin"></i> Edit Profile </blink>
                              </strong>
                          </h3>
                      </div><!-- /.box-header -->
                      <div class="box-body">
                        <div class="form-group">

                          <div class="col-md-12">
                          <input type="text" class="form-control" id="email" name="name" placeholder="Fullname" value="<?php echo $p['name']; ?>" autocomplete="off" maxlength="250" />
                          </div>
                          </div>
                          <div class="form-group">

                            <div class="col-md-12">
                            <input type="text" class="form-control" id="email" name="location" placeholder="Location" value="<?php echo $p['location']; ?>" autocomplete="off" maxlength="250" />
                            </div>
                            </div>
                        <div class="form-group">

                        <div class="col-md-12">
                        <input type="text" class="form-control" id="email" name="number" placeholder="Mobile Number" value="<?php echo $p['number']; ?>" autocomplete="off" maxlength="250" />
                        </div>
                        </div>
                        
                         <div class="form-group">
                        <div class="col-md-12">
                        <input type="text" class="form-control" id="email" name="eligible" placeholder="Eligible: type true or false to make user eligible to recieve cash"  autocomplete="off"  />
                        </div>
                        </div>

                        <div class="form-group">
                        <div class="col-md-12">
                        <input type="text" class="form-control" id="email" name="matches" placeholder="Enter matches"  autocomplete="off"  />
                        </div>
                        </div>

                        <div class="form-group">

                        <div class="col-md-12">
                        <select name="bundle" class="form-control">
						<option value="<?php echo $p['bundle']; ?>"> <?php echo $p['bundle']; ?> </option>
                        <option value="bundle_one"> pack - 2k </option>
                        <option value="bundle_two"> pack  - 5k </option>
                        
                        </select>   </div>
                        </div>


                        <div class="form-group">
                        <div class="col-md-12">
                        <textarea type="text" class="form-control" id="email" name="account_name" placeholder="Account name" value="" autocomplete="off" maxlength="250"><?php echo $p['account_name'];?></textarea>
                        </div>
                        </div>

                        <div class="form-group">
                        <div class="col-md-12">
                        <textarea type="text" class="form-control" id="email" name="account_number" placeholder="Account number" value="" autocomplete="off" maxlength="250"><?php echo $p['account_number'];?></textarea>
                        </div>
                        </div>

                        <div class="form-group">
                        <div class="col-md-12">
                        <textarea type="text" class="form-control" id="email" name="bank" placeholder="Bank" value="" autocomplete="off" maxlength="250"><?php echo $p['bank'];?></textarea>
                        </div>
                        </div>

                        <div class="form-group">

                        <div class="col-md-12">
                        <input type="password"  class="form-control" id="password" name="password" placeholder="Change Password?" value="" maxlength="100" />
                        </div>
                        </div>


	<button type="submit" class="btn btn-block btn-success"> Make Changes</button>

<form action='<?php echo $_SERVER['PHP_SELF']?>'  method='post'>
<div class="form-group">
<div class="col-md-12">
<textarea rows="4" col="50" class="form-control" id="email" name="message_area" placeholder="Post a reply" autocomplete="off" maxlength="250"  data-toggle="tooltip" title="Message" ></textarea>
</div>
</div>
<button type="submit" name='ad_message' class="btn btn-block btn-success">Reply to user message </button>
<span class='text-success'><?php echo @$m; ?></span>
</form>

</div>
</div>
</div>

<!--admin message-->
<?php 
         $msg_query = $this->db->query("SELECT * FROM `message` WHERE number='".$p['number']."'  ORDER BY ID ASC");
        $msg_count=$msg_query->num_rows();
?>
<div class="col-sm-6 well well-success" style="height: 600px; overflow-y: scroll; background-color: #D2D7D3">
<p> <?php if($msg_count>0){

                                    $msg = $msg_query->row_array();
                                foreach ($msg_query->result_array() as $m){ 
                                    $msg_out=$m['msg_out'];
                                    $msg_in=$m['msg_in'];
                                    $date=$m['time'];
                                    if($msg_out!=''){
                                    ?>
                                      <div class="row" style="padding-bottom: 2px;">
                                        <div id="msg_in" class="col-sm-6 style-default-dark" style="border:solid blue 1px; border-radius: 5px;"> 
                                           <?php echo $msg_out;?> <br/>
                                           <p class="small text-muted"><i class="fa fa-clock-o"></i> <?php echo $date; ?></p>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($msg_in!=''){
                                    ?>
                                    <div class="row" style="padding-bottom: 2px;">
                                        <div id="msg_in" class="col-sm-6 col-sm-offset-6 style-default-dark" style="border:solid blue 1px; border-radius: 5px;"> <?php echo $msg_in;?> <br/>
                                         <p class="small text-muted"><i class="fa fa-clock-o"></i> <?php echo $date; ?></p>
                                        </div>
                                      </div>
                                     
                                     
                                    <?php } ?>
                              <?php } }?></p>


</div>
</div>
