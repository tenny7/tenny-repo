<div class="main-container">
<div class="container">
<div class="row">
<div class="col-md-8  col-md-offset-2 page-content">
<div class="inner-box category-content" style="border-radius: 24px;">
<h2 class="title-2">
<span class="fa fa-dashcube"></span> About <?php echo $site_name; ?> </h2>
<style type="text/css">.about-container h4{font-weight:bold;font-size:16px;}</style>
<div style="font-size: 14px;" class="about-container">
<p>
<?php echo $site_name; ?> is a peer to peer community built to last long. The packages listed here are to enable you make safe investments and get good returns.
Invest in any of the packages offered and get 100% return.
</p>
<br/>
<p>
<h4>HOW IT WORKS!</h4>
<ol>
<li>1. Log on to Upliftas.com</li>
<li>2. Register!</li>
<li>3.Make a donation to your upline depending on your category( N2000 and N5000).</li>
</ol>
</p>
<p>
Receive exactly the same amount you donated to your Upline from the direct Downlines matched to you directly.
You can click on the "Unserious user button" to push aside people who register just to joke around." 
After being matched to recieve from your two downlines, you can now click on the "donate again button" and repeat the process
</p>
<table class="table table-bordered">
	<div style='background: white; padding: 5px; border: 2px solid #ddd;'> Categories </div>
    <thead>
      <tr>
        <th>Category</th>
        <th>Donation</th>
        <th>Downlines</th>
		<th>Total Income</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>N2,000</td>
        <td>2</td>
		<td>N4,000</td>
      </tr>
      <tr>
        <td>2</td>
        <td>N5,000</td>
        <td>2</td>
		<td>N10,000</td>
      </tr>
    </tbody>
  </table>
  
  <hr>
  
 
  
  <hr>
    
<p>
</p>

<p>

</p>
</div>
</div>
</div>
<div class="col-md-4">
</div>

</div>

</div>

</div>
