








<div class="main-container">

<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2 page-content" >
<div class="inner-box category-content" style="border-radius: 24px;">
<h2 class="title-2">
<span class="fa fa-headphones"></span>
<?php echo $site_name; ?> Support Centre
</h2>
<p>
<h4>Welcome to the Support Center</h4>
Here at <?php echo $site_name; ?>, we're dedicated to making our users happy.
If you have a question or concern, you've come to the right place.
Send a message to support
<form method="post" action="support">
<div class="form-group">
<textarea rows=5 col=50 class="form-control control-6-rows" name="message" id="message" placeholder="You can type your message here"></textarea>
</div>
<div class="form-group">
<input type="submit" class="btn btn-primary btn-block" name="send_msg" id="send_msg" value="Send" />
</div>



</form>




</p>
<hr/>



<?php
if(isset($_POST['send_msg'])){

        $msg_out=$_POST['message'];

        $date=date('Y-m-d H:i:s');
                
                 $data = array('id' => '', 'number' =>$this->session->number, 'msg_in' => '', 'msg_out' => $msg_out, 'time' => $date);
   
  






echo "<center><h3 style='padding:2px;'>Message sent!, check your inbox for reply</h3></center>";
 return $this->db->insert('message', $data);

}
?>

</div>
</div>
</div>
</div>


</div>

</div>

</div>