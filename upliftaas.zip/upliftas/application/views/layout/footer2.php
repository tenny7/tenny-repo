<!-- Main Footer -->
     
    <script type="text/javascript" src="<?php echo base_url('assets/js/jQuery/jquery-2.2.3.min.js'); ?>"></script>

    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/app.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/datatables/jquery.dataTables.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/datatables/dataTables.bootstrap.js'); ?>"></script>
</div>
<script type="text/javascript">
  $('#header_text').addClass('animated wobble');
</script>
<script src="<?php echo base_url('assets/Lettering/jquery.lettering.js'); ?>"></script>
<script src="$('#header_text').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', Invite your friends);"></script>
<script>

    $('#table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
</script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.countdown.js'); ?>"></script>
</div>

<!-- ./wrapper -->
</body>
</html>