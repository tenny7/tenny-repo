<?php 
         $msg_query_count = $this->db->query("SELECT * FROM `message` WHERE number='".$this->session->number."' AND msg_in IS NOT NULL");
          $msg_query = $this->db->query("SELECT * FROM `message` WHERE number='".$this->session->number."' AND msg_in IS NOT NULL ORDER BY ID DESC LIMIT 20");
        $msg_count=$msg_query_count->num_rows();
?>





<!DOCTYPE html>
<html lang="en" class="no-js" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title><?php echo $title; ?>  </title>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"/>
<meta name="description" content="<?php echo $site_name; ?> is a global charity organisation that helps its esteemed members to donate to one another and help improve the standard of living of the entire community at large."/>
<meta name="keywords" content="charity, foundation, giver, helper, poverty alleviation, earn money"/>
<meta name="author" content=""/>
<meta name="robots" content="index"/>
<meta name="googlebot" content="index"/>
<meta name="robots" content="follow"/>
<meta name="robots" content="nocache"/>
<meta http-equiv="cache-control" content="no-cache"/>
<meta http-equiv="expires" content="-1"/>
<meta property="og:site_name" content="<?php echo $site_name; ?>"/>
<meta property="og:url" content="<?php echo base_url(); ?>"/>
<meta property="og:title" content="<?php echo $site_name; ?> - P2P global donation platform - Truly, it pays to give!"/>
<meta property="og:type" content="product"/>
<meta property="og:description" content="<?php echo $site_name; ?> is a global charity organisation that helps its esteemed members to donate to one another and help improve the standard of living of the entire community at large."/>
<meta property="fb:app_id" content=""/>
<link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet">
<script src="https://use.fontawesome.com/1bcaa14cff.js"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/css/dataTables.bootstrap.css'); ?>">
<link href="<?php echo base_url('assets/css/AdminLTE.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/css/skins/skin-black.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="assets/animate/animate.min.css">
<link rel="stylesheet" href="assets/textillate/animate.min.css">
<!--[if lt IE 9]>
        <script type="text/javascript" src="https://www.smile2charity.com/static/third_party/bootstrap/js/html5shiv.min.js?v=52c3773b548d898b265fea0710160833f7bd437b"></script>
        <script type="text/javascript" src="https://www.smile2charity.com/static/third_party/bootstrap/js/respond.min.js?v=52c3773b548d898b265fea0710160833f7bd437b"></script>
    <![endif]-->
</head>
<link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet">
<body class="" style="background-image: url('assets/img/wood002.jpg');">
<div class="wrapper">





<nav class="navbar navbar-static-top navbar-inverse" role="navigation"> <!--when i added navbar inverse, the color of the navbar changed-->

<ul class="nav  navbar-nav navbar-right top-nav">

<li> <a href="<?php echo base_url(); ?>"><i class="fa fa-home"></i>    Home</a> </li>


<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown"></i>Inbox <span class="badge"><?php echo $msg_count; ?></span><b class="caret"></b></a>
    <ul class="dropdown-menu message-dropdown">
        <li class="message-preview">
            <a href="#">
                <div class="media">
                    
                    <div class="media-body">
                        <h5 class="media-heading"><strong>Message from Admin</strong>
                        </h5>
                        
                        <p> <?php if($msg_count>0){

                                    $msg = $msg_query->row_array();
                                foreach ($msg_query->result_array() as $m){ 
                                    $msg_in=$m['msg_in'];
                                    $date=$m['time'];
                                    ?>
                                    <div><?php echo $msg_in;?> <br/></div>
                                     <p class="small text-muted"><i class="fa fa-clock-o"></i> <?php echo $date; ?></p>
                                      <hr style="padding:2px; margin: 0px;">
                              <?php } }?></p>
                    </div>
                </div>
            </a>
        </li>
    </ul>
</li>





<li class="active"><a href="<?php echo base_url('dashboard'); ?>"><i class="fa fa-area-chart" aria-hidden="true"></i> <span>Dashboard</span></a></li>
 <!-- Top Menu Items -->
         <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $name; ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo base_url('dashboard/edit'); ?>"><i class="fa fa-fw fa-gear"></i> Profile Update</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('support'); ?>"><i class="fa fa-fw fa-envelope"></i> Private Message to admin</a>
                        </li>
                        <li>
                        <a href="<?php echo base_url('dashboard/received_donations'); ?>"> <i class="fa fa-credit-card"></i> GH Timeline</a>
                        </li>
                        <li>
                        <a href="<?php echo base_url('dashboard/sent_donations'); ?>"> <i class="fa fa-credit-card"></i> PH Timeline</a>
                        </li>
                        
                    </ul>
                </li> 
                <li>
                    <a href="<?php echo base_url('logout'); ?>"><i class="fa fa-fw fa-power-off"></i> Log Out   </a>
                </li>  
                 
                
            </ul>
</nav>



<div class="container" >
<section class="content" style="background:#ececec; border-radius:20px;">
<?php if($this->session->flashdata('msg')){ ?>
<div class="global-error">

</div>
<?php } ?>

<div class="global-error">
<center><h1 class="animated   rotateInDownRight" id="header_text" 
style="-vendor-animation-duration: 3s; -vendor-animation-delay: 2s; -vendor-animation-iteration-count: infinite;"><?php echo $this->dashboard_model->get_announcement(); ?></h1></center>

</div>