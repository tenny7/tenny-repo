<div class="main-container">
<div class="container">
<div class="row">

  <?php if(!empty($this->session->flashdata('msg2'))){ ?>
    
  <?php } ?>

<?php if(!empty($msg)){ ?>
			<style type="text/css">
	        .Absolute-Center {
			  margin: auto;
			  position: absolute;
			  top: 0; left: 0; bottom: 0; right: 0;
			}

			.Absolute-Center.is-Responsive {
			  width: 50%; 
			  height: 50%;
			  min-width: 200px;
			  max-width: 400px;
			  padding: 40px;
			}
			</style>


           <div class="col-lg-6 col-md-6 col-sm-6 Absolute-Center is-Responsive">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-support fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $msg; ?>  </div>
                                        <div> <?php } ?></div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo base_url('dash'); ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">Dashboard</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
  





</div>
</div>
</div>
