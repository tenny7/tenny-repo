

<div class="main-container">
<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2 page-content " >
<div class="inner-box category-content" style="border-radius:24px;">
<h2 class="title-2" align="center">
<span class="fa fa-user"></span> JOIN NOW
</h2>


<hr/>
<div class="row">
<div class="col-sm-12" >
<?php echo form_open('register'); ?>
<?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>
<div class="form-group">
  <div class="col-md-12">
  <input type="text" class="form-control" id="email" name="name" placeholder="Fullname" value="" autocomplete="off" maxlength="30"  data-placement="top" data-toggle="tooltip" title="Please Enter Your Full Name" />
  </div>
  </div>
  <br/>

  <div class="form-group">
    <div class="col-md-12">
    <input type="text" class="form-control" id="email" name="location" placeholder="Location" value="" autocomplete="off" maxlength="30" data-toggle="tooltip" title="Location"  />
    </div>
    </div>
    <br/>

<div class="form-group">
<div class="col-md-12">
<input type="text" class="form-control" id="email" name="number" placeholder="Mobile  Number" value="" autocomplete="off" minlength="11" maxlength="11"  data-toggle="tooltip" title="Phone Number" pattern="\d*" />
</div>
</div>
<br/>

<div class="form-group">
<div class="col-md-12">
<select name="bundle" class="form-control">
<option value="Select a payment plan"> Choose a category </option>
<option value="bundle_one">  ₦2000 </option>
<option value="bundle_two">  ₦5,000 </option>
</select>   </div>
</div>


<div class="form-group">
<div class="col-md-12">
<input type="text" class="form-control" id="email" name="account_name" placeholder="Account Name" autocomplete="off" maxlength="50"  data-toggle="tooltip" title="Bank Account Name" />
</div>
</div>
<br/>
<!--edit of form starts here-->

<div class="form-group">
<div class="col-md-12">
<input type="text" class="form-control" id="email" name="account_number" placeholder="Account Number" autocomplete="off"  minlength="10" maxlength="10"  data-toggle="tooltip" title="Enter Your Account number" pattern="\d*" />
</div>
</div>
<br/>

<div class="form-group">
<div class="col-md-12">
<input type="text" class="form-control" id="email" name="bank" placeholder="Bank Name" autocomplete="off" maxlength="250"  data-toggle="tooltip" title=" Bank name"  />
</div>
</div>
<br/>

<!--edit ends here-->

<div class="form-group">
<div class="col-md-12">
<input type="password"  class="form-control" id="password" name="password" placeholder="Choose a Password" value=""  maxlength="100" data-toggle="tooltip" title=" Password" />

</div>
</div>
<br/>

<div class="form-group">
<div class="col-md-12">
<input type="password"  class="form-control" id="password_again" name="c_password" placeholder="Confirm Password" value="" maxlength="100" data-toggle="tooltip" title="Confirm Password " />
</div>
</div>
<br/>


<div class="form-group">
<div class="col-md-12" style="padding: 2px 15px;">
<p style="">
By clicking on the button below, you state that you have read and 
 agree to our <a href="<?php echo base_url('terms'); ?>" target="_blank">terms &amp; conditions</a> and <a href="<?php echo base_url('privacy'); ?>" target="_blank">privacy policy</a>.
</p>
</div>
</div>
<br/>

<div class="form-group">
<div class="col-md-12" style="text-align:center; ;">
<input type="hidden" name="action" value="REGISTER"/>
<button id="submit_btn" name="submit_btn" type="submit" class="btn btn-lg " value="REGISTER" style="background-color: #a3d5e2;">Register Me</span></button>

<br>
<br>
</div>
</div>
</form>
</div>
</div>
</div>
</div>

</div>

</div>

</div>