            <?php  if($eligible != 'true') { ?>

            
              

         <!-- panels -->
            <div class="row">
          
              <?php if(!empty($this->session->flashdata('smsg'))): ?>
              <div class="alert alert-danger"> <?php echo $this->session->flashdata('smsg'); ?> </div>
              <?php endif; ?>
              <?php if($bundle=="bundle_one")
              $bund="₦2,000"; ?>
              <?php if($bundle=="bundle_two")
              $bund="₦5,000"; ?>
              
              

           <div class="col-lg-4 col-sm-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-fw fa-user"></i> My Transaction Timeline</h3>
                            </div>

                     <div class="panel-body">
                                <div class="list-group">
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Category</span>
                                        <i class="fa fa-fw fa-user"></i> <?php echo $bund; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Pending Donors</span>
                                        <i class="fa fa-fw fa-comment"></i> <?php echo $matches; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Total money Collected</span>
                                        <i class="fa fa-fw fa-truck"></i> ₦<?php echo $received_cash; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge"> Total Money donated</span>
                                        <i class="fa fa-fw fa-comment"></i> </i> ₦<?php echo $sent_cash; ?>
                                    </a>
                                    
                                      
                                </div>
                        </div>
                    </div>
            </div>


               
              <?php if($d_name!=''){?>
                       <div class="col-lg-4 col-sm-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-fw fa-user"></i> You are matched to donate to</h3>
                            </div>
                            <div class="panel-body">
                                <div class="list-group">
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Name</span>
                                        <i class="fa fa-fw fa-user"></i> <?php echo $d_name; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Account Number</span>
                                        <i class="fa fa-fw fa-comment"></i> <?php echo $d_account_number; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Bank</span>
                                        <i class="fa fa-fw fa-truck"></i> <?php echo $d_bank; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Phone Number</span>
                                        <i class="fa fa-fw fa-comment"></i> </i> <?php echo $d_number; ?>
                                    </a>
                                   
                            
                                </div>
                                
                            </div>
                        </div>
                    </div>




                      <div class="col-lg-4 col-sm-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-fw fa-user"></i> My Personal Details</h3>
                            </div>

                     <div class="panel-body">
                                <div class="list-group">
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Name</span>
                                        <i class="fa fa-fw fa-user"></i> <?php echo $name; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Account Number</span>
                                        <i class="fa fa-fw fa-comment"></i> <?php echo $account_number; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Bank</span>
                                        <i class="fa fa-fw fa-truck"></i> <?php echo $bank; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Phone Number</span>
                                        <i class="fa fa-fw fa-comment"></i> </i> <?php echo $number; ?>
                                    </a>
                                    
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Sent Donations</span>
                                        <i class="fa fa-fw fa-money"></i></i> ₦<?php echo $sent_cash; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Recieved donations</span>
                                        <i class="fa fa-fw fa-money"> </i>₦<?php echo $received_cash; ?>
                                    </a>
                                      
                                </div>
                        </div>
                    </div>
                </div><!--end row-->

                   
              <?php } ?>
             


            

       

          <?php } else { ?>
          <!-- panels -->
            <div class="row">

      
          
          <?php if(!empty($this->session->flashdata('cmsg'))): ?>
          <div class="alert alert-info"> <?php echo $this->session->flashdata('cmsg'); ?> </div>
          <?php endif; ?>
          <div class="card" >
            
           <?php if($matches!="0") { ?>
            <div class="card-block">
              <p class="card-text"><div class="alert" style="padding-top:0px; color:black;"> <center><h3><i class="fa fa-credit-card" aria-hidden="true"></i> You will receive shortly</h3></center></div>
              <?php }?>
          <?php
          $number = $this->session->number;
          $check_donation_query = $this->db->query("SELECT * FROM donations WHERE donates_to='$number' AND status='Pending'");
          $result = $check_donation_query->result_array();
          //get user Details
             ?>


            
             <div class="row" style="padding: 10px;">
             <?php foreach($result as $row): ?>
              <div class="col-lg-6 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge">Get help of ₦<?php echo $row['amount']; ?> from:</div>
                                        <div>Name: </span><?php echo $this->dashboard_model->get_details($row['user'])->name; ?>
                                        phone no: <?php echo $row['user']; ?> </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left"><a class="btn btn-success btn-sm" href="<?php echo base_url('dashboard/confirm_proof/'.$row['user']); ?>">I have recieved</a> | <a class="btn btn-danger btn-sm" href="<?php echo base_url('dashboard/reject_proof/'.$row['user']); ?>">Unserious user</a></span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
              </div>



              <?php if($bundle=="bundle_one")
              $bund=" ₦2000"; ?>
              <?php if($bundle=="bundle_two")
              $bund=" ₦5,000"; ?>
              




`           <div class="row" style="padding: 10px;">
              <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-fw fa-user"></i> My Transaction Timeline</h3>
                            </div>

                     <div class="panel-body" style="padding-bottom: 140px;">
                                <div class="list-group">
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Category</span>
                                        <i class="fa fa-fw fa-user"></i> <?php echo $bund; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Pending Donors</span>
                                        <i class="fa fa-fw fa-comment"></i> <?php echo $matches; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Total money Collected</span>
                                        <i class="fa fa-fw fa-truck"></i> ₦<?php echo $received_cash; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge"> Total Money donated</span>
                                        <i class="fa fa-fw fa-comment"></i> </i> ₦<?php echo $sent_cash; ?>
                                    </a>
                                    
                                      
                                </div>
                        </div>
                    </div>
            </div>

            <div class="col-lg-4 col-sm-4">
              <?php
                if($matches === '0' && $swift <> 'Swift 2') {
                ?>
                <a class="btn btn-success btn-sm btn-block" href="<?php echo base_url('dashboard/recycle'); ?>">Donate again</a><!--<a class="btn btn-success btn-lg" href="<?php // echo base_url('dashboard/upgrade_swift'); ?>">Upgrade</a>-->
                <?php } ?>
            </div>
               
               


                 <div class="col-lg-4 col-sm-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-fw fa-user"></i> My Personal Details  <?php           
                
$msg_query = $this->db->query("SELECT * FROM `donations` WHERE user='".$this->session->number."'");
 $msg = $msg_query->row_array();
                                foreach ($msg_query->result_array() as $m){ 
                                    $time=$m['time'];
echo "------------------------------$time";
}
                            ?>     </h3>
                            </div>

                     <div class="panel-body">
                                <div class="list-group">
                                   <a href="#" class="list-group-item">
                                        <span class="badge">Name</span>
                                        <i class="fa fa-fw fa-user"></i> <?php echo $name; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Account Number</span>
                                        <i class="fa fa-fw fa-comment"></i> <?php echo $account_number; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Bank</span>
                                        <i class="fa fa-fw fa-truck"></i> <?php echo $bank; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Phone Number</span>
                                        <i class="fa fa-fw fa-comment"></i> </i> <?php echo $number; ?>
                                    </a>
                                    
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Sent Donations</span>
                                        <i class="fa fa-fw fa-money"></i></i> ₦<?php echo $sent_cash; ?>
                                    </a>
                                    <a href="#" class="list-group-item">
                                        <span class="badge">Recieved donations</span>
                                        <i class="fa fa-fw fa-money"> </i>₦<?php echo $received_cash; ?>
                                    </a>
                                      
                                </div>
                        </div>
                    </div>

                <!-- fix for small devices only -->
                <div class="clearfix visible-sm-block"></div>
               
              </div>

               
              
          



    <div>Registration closes in <span id="time"></span> minutes!</div>


          



      <script type="text/javascript">
     // alert('<?php echo $time;?>');
     // alert( Date.parse("2011-10-10 14:48:00")/1000);
      function startTimer(duration, display) {
    var start = Date.now(),
        diff,
        minutes,
        seconds;
    function timer() {
        // get the number of seconds that have elapsed since 
        // startTimer() was called
        diff = duration - (((Date.now() - start) / 1000) | 0);

        // does the same job as parseInt truncates the float
        minutes = (diff / 60) | 0;
        seconds = (diff % 60) | 0;

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds; 

        if (diff <= 0) {
            // add one second so that the count down starts at the full duration
            // example 05:00 not 04:59
            start = Date.now() + 1000;
        }
    };
    // we don't want to wait a full second before the timer starts
    timer();
    setInterval(timer, 1000);
}

window.onload = function () {
    var fiveMinutes = 60 * 60,
        display = document.querySelector('#time');
    startTimer(fiveMinutes, display);
};
  </script>
  <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.countdown.js'); ?>"></script>
<?php } ?>
        </div><!-- /.row -->
        
         
          </div>
   
    </div>
    
    </div>
    

    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->